from django.contrib import admin
from .models import Pendulum

admin.site.register(Pendulum)